---
title: GitHubのリモートブランチを削除する
created_at: 2020-11-28
tags:
- GitHub
---

ブラウザからできます。

## リポジトリを開く
はい

![Imgur](https://imgur.com/1dZQe8v.png)

## branches を押す
ここ

![Imgur](https://imgur.com/KuOq8yr.png)

## ゴミ箱ボタンを押す
`Your branches`と`Active branches`の2つに表示されてても、どちらか片方を押せば両方消えます。

![Imgur](https://imgur.com/gKlbMoa.png)

おしまい