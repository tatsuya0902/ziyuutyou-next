---
title: JetpackComposeのTextFieldをViewのEditTextに似せたい
created_at: 2021-05-02
tags:
- Android
- Kotlin
- JetpackCompose
---

`BasicTextField`を使えばいいです。
