# components
Androidで言うところのCustomView。  
他で使いまわせそうなUIの部品を切り出しておく。