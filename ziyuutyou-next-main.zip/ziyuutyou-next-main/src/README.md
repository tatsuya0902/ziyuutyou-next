# src
静的書き出し時に呼ぶ関数 とか componentsには入れたくないTypeScriptのコードとかを置いてる。  
テーマ設定とかAnalytics関係とか