module.exports = {
    siteUrl: 'https://takusan.negitoro.dev',
    generateRobotsTxt: true,
    outDir: './out'
}